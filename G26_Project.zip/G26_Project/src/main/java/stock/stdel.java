package stock;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class stdel {

	
	public static void upd(int str)
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			//out.print("Hello1");			
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","root");
			PreparedStatement pst=conn.prepareStatement("DELETE FROM stock WHERE id="+str);
			int i=pst.executeUpdate();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
