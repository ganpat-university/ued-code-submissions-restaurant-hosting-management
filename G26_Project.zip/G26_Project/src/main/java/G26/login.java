package G26;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns="/inp")
public class login extends HttpServlet {
	
	public void init() throws ServletException
	{
		
	}
	
	public void doPost(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		int i=0;
		res.setContentType("text/html");
		PrintWriter pw=res.getWriter();
		String uname=req.getParameter("un");
		String pas=req.getParameter("ps");
		String un="",ps="";
		try
		{
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","root");
			PreparedStatement pst= con.prepareStatement("SELECT * FROM pass WHERE Username= '"+uname+"'"); 
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				un=rs.getString("Username");
				ps=rs.getString("Password");
			}
			
			if(uname.contentEquals(un) && pas.contentEquals(ps))
			{
				//pw.print("<center><h1>"+"Welcome "+uname+"</h1></center>");
				//pw.print("I am in if");
				RequestDispatcher rd=req.getRequestDispatcher("modules.html");
				rd.include(req, res);
			}
			else
			{
				pw.print("<center><h1>"+"Oops! Please enter the correct values!!"+"</h1></center>");
				//pw.print("I am in else");
				RequestDispatcher rd=req.getRequestDispatcher("login_mod.html");
				rd.include(req, res);
			}
		}
		catch(Exception e)
		{
			//pw.print("I am in catch");
			pw.print("Oops! Please enter the correct values!!");
		}
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
