package G26;
import java.sql.*;
import java.util.*;
import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet(urlPatterns="/xyz")
public class Review extends HttpServlet{
	
		@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	PrintWriter out = resp.getWriter();
	String email = req.getParameter("email");
    String username = req.getParameter("userName");
    String feedback = req.getParameter("subject");
   
    
		
		try {
			
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","root");
			PreparedStatement prp=con.prepareStatement("insert into fb values(?,?,?)");
			prp.setString(1, email);
			prp.setString(2, username);
			prp.setString(3, feedback);
			
			prp.executeUpdate();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
						e.printStackTrace();
					}
		}
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}
}


	
