package ordermanagement;


import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Connection;

import java.lang.*;

import java.net.*;

public class updord {

		
	public static void update(int str)
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			//out.print("Hello1");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","root");
			//out.print(no);
			PreparedStatement pst=conn.prepareStatement("UPDATE on_or_st SET Payment_Status='Received' WHERE Order_ID= "+str+";");
			pst.executeUpdate();
			PreparedStatement pst1=conn.prepareStatement("DELETE FROM on_or_st WHERE Order_ID="+str);
			pst1.executeUpdate();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
