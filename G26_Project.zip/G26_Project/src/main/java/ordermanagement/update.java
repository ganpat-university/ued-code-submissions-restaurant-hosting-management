package ordermanagement;

import java.sql.DriverManager;
import java.io.IOException;
import java.sql.*;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
@WebServlet(urlPatterns="/update")

public class update extends HttpServlet{

	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int ordid=Integer.parseInt(request.getParameter("orid"));
		updord.update(ordid);
		RequestDispatcher rd=request.getRequestDispatcher("order_tab.jsp");
		rd.forward(request, response);
	}

}
