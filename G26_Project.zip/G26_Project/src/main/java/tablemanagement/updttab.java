package tablemanagement;

import java.io.IOException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import ordermanagement.updord;
@WebServlet(urlPatterns="/updttab")

public class updttab extends HttpServlet{

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int tblid=Integer.parseInt(request.getParameter("tbid"));
		uptab.upd(tblid);
		RequestDispatcher rd=request.getRequestDispatcher("tab_res.jsp");
		rd.forward(request, response);
	}

}
