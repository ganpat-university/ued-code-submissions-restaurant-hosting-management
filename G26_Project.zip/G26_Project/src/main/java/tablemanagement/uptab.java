package tablemanagement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class uptab {

	public static void upd(int str)
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			//out.print("Hello1");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","root");
			//out.print("Hello2");
			PreparedStatement pst=conn.prepareStatement("UPDATE table_res SET Availabilty='YES',Persons=0,`Time`=' ',Mobile=' ',`Date`=' ' WHERE Table_No="+str+";");
			pst.executeUpdate();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
