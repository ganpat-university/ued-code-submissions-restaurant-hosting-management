create table table_res(
						Table_No int(4),
                        Availabilty varchar(10),
                        Reserved_By varchar(50),
                        Persons int(4),
                        `Time` varchar(50)
						);