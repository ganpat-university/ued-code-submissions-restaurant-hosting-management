create table on_or_st(
						Order_ID int(5) primary key auto_increment,
						Items varchar(500),
                        `Status` varchar(20),
                        Total int(5),                        
                        Payment_Mode varchar(10),
                        Payment_Status varchar(20)
                        );